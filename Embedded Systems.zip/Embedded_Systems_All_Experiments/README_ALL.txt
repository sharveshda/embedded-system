EMBEDDED SYSTEMS PRACTICALS — EXPERIMENTS 01 TO 17
=================================================

This package contains one separate folder for each of the 17 experiments.
Each folder includes:
- Source code (Arduino / Embedded C / SystemC / Python as applicable)
- README.txt with required software and setup notes
- expected_software_output.txt with representative terminal output

SOFTWARE QUICK MAP
01-04: Arduino IDE + Proteus 8
05-07: Keil µVision + LPC2148 board + Flash Magic / serial terminal
08-09, 11: Ubuntu/WSL + g++ + SystemC/TLM-2.0
10, 12: ESP32 Arduino firmware + Python 3 + PySerial + esptool
13-17: Arduino IDE + ESP32 board package (FreeRTOS)

IMPORTANT LIMITATIONS
- Proteus project files (.pdsprj), Keil project files, SystemC libraries, ESP32 binaries,
  and genuine simulator screenshots are not included. Those must be created/run in the
  respective applications and depend on installed libraries and hardware.
- The output files are sample/expected outputs. Replace them with your actual readings.
- Experiment 08 assumes a 1 ns clock period to produce five positive edges by 5 ns.
- Experiments 13-17 use the ESP32 Arduino core's built-in FreeRTOS APIs.
- Check the individual README before wiring or flashing. Never connect motors/fans directly
  to microcontroller GPIO pins; use suitable driver circuitry.
